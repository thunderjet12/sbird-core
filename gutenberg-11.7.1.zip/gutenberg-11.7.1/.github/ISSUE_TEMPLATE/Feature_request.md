---
name: Feature request
about: Propose an idea for a feature or an enhancement

---

## What problem does this address?
<!--
Please describe if this feature or enhancement is related to a current problem
or pain point. For example, "I'm always frustrated when ..." or "It is currently
difficult to ...".
-->

## What is your proposed solution?
<!--
Please outline the feature or enhancement that you want and how it addresses any
problem identified above.
-->
