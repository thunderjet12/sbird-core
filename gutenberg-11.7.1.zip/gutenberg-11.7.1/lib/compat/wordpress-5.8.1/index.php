<?php
/**
 * Temporary compatibility shims for features present in Gutenberg.
 *
 * @package gutenberg
 */

// Load the polyfills.
require_once __DIR__ . '/widget-render-api-endpoint/index.php';
