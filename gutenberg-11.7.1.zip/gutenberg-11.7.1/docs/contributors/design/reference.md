# Reference

-   [Glossary](/docs/getting-started/glossary.md)
-   [Coding Guidelines](/docs/contributors/code/coding-guidelines.md)
-   [Testing Overview](/docs/contributors/code/testing-overview.md)
-   [Frequently Asked Questions](/docs/getting-started/faq.md)

## Logo

<img width="200" src="https://raw.githubusercontent.com/WordPress/gutenberg/HEAD/docs/final-g-wapuu-black.svg?sanitize=true" alt="Gutenberg Logo" />

Released under GPL license, made by [Cristel Rossignol](https://twitter.com/cristelrossi).

[Download the SVG logo](https://github.com/WordPress/gutenberg/blob/HEAD/docs/final-g-wapuu-black.svg).

## Mockups

Mockup Sketch files are available in [the Design section](/docs/how-to-guides/designers/design-resources.md).
