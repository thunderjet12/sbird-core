# Getting Started

## [Tutorials](/docs/getting-started/tutorials/README.md)

-   [Development Environment](/docs/getting-started/tutorials/devenv/README.md)
-   [Create a Block Tutorial](/docs/getting-started/tutorials/create-block/README.md)

## [Glossary](/docs/getting-started/glossary.md)

## [FAQ](/docs/getting-started/faq.md)

## [History](/docs/getting-started/history.md)

## [Outreach](/docs/getting-started/outreach.md)
