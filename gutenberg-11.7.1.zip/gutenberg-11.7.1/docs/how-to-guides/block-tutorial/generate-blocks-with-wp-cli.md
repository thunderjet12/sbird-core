# Generate Blocks with WP-CLI

## WARNING

**Deprecated:** It is no longer recommended to use WP-CLI or create-guten-block to generate block scaffolding.

The official script to generate a block is the new [@wordpress/create-block](/packages/create-block/README.md) package. This package follows the new block directory guidelines, and creates the proper block, environment, and standards set by the project. See the new [Create a Block tutorial](/docs/getting-started/tutorials/create-block/README.md) for a complete walk-through.
