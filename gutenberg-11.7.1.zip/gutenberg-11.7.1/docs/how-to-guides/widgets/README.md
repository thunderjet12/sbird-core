# Widgets

The Gutenberg plugin replaces the Widgets Editor screen in WP Admin with a new screen based on the WordPress block editor.

**Contents**

- [Widgets Block Editor overview](/docs/how-to-guides/widgets/overview.md)
- [Restoring the old Widgets Editor](/docs/how-to-guides/widgets/opting-out.md)
- [Ensuring compatibility with the Legacy Widget block](/docs/how-to-guides/widgets/legacy-widget-block.md)
