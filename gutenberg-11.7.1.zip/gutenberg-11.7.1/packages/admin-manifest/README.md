# Admin Manifest

Dynamically creates a Web App [manifest](https://w3c.github.io/manifest/) and registers the service worker for the admin.
