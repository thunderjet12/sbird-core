<!-- Learn how to maintain this file at https://github.com/WordPress/gutenberg/tree/HEAD/packages#maintaining-changelogs. -->

## Unreleased

## 2.2.0 (2021-07-21)

## 2.1.0 (2021-05-20)

## 2.0.0 (2021-05-14)

### Breaking Changes

-   Drop support for Internet Explorer 11 ([#31110](https://github.com/WordPress/gutenberg/pull/31110)). Learn more at https://make.wordpress.org/core/2021/04/22/ie-11-support-phase-out-plan/.
-   Increase the minimum Node.js version to v12 matching Long Term Support releases ([#31270](https://github.com/WordPress/gutenberg/pull/31270)). Learn more at https://nodejs.org/en/about/releases/.

## 1.25.0 (2021-03-17)

## 1.24.0 (2020-12-17)

### New Feature

-   Added a store definition `store` for the annotations namespace to use with `@wordpress/data` API ([#26655](https://github.com/WordPress/gutenberg/pull/26655)).

## 1.0.5 (2019-01-03)

## 1.0.4 (2018-12-12)

## 1.0.3 (2018-11-21)

## 1.0.2 (2018-11-20)

## 1.0.1 (2018-11-15)

## 1.0.0 (2018-11-12)

### New Features

-   Implement annotations API in the editor.
