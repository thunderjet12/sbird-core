<!-- Learn how to maintain this file at https://github.com/WordPress/gutenberg/tree/HEAD/packages#maintaining-changelogs. -->

## Unreleased

## 4.0.0 (2021-09-09)

### Breaking Change

-   Remove the background-colors, foreground-colors, and gradient-colors mixins.

## 2.0.0 (2020-07-07)

### Breaking Changes

-   Remove the AdminColorThemes JavaScript variables.
-   Retire numerous colors and old grays, indicate others for deprecation.

## 1.2.0 (2020-01-13)

### Bug Fix

-   Import `colors` into `variables` since the latter depends on the former.
