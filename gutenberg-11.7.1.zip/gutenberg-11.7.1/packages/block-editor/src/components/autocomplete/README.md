# Autocomplete

This is an Autocomplete component for use in block UI. It is based on `Autocomplete` from `@wordpress/components` and takes the same props. In addition, it passes its autocompleters through a `editor.Autocomplete.completers` filter to give developers an opportunity to override or extend them.

The autocompleter interface is documented with the original `Autocomplete` component in `@wordpress/components`.
