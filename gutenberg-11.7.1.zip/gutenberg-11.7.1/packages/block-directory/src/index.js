/**
 * Internal dependencies
 */
import './plugins';

export { store } from './store';
